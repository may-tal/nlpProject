Folder "need sort":
    every message separated by "==================="
    
*.neg, *.pos files:
    open them with text editor app
    
    